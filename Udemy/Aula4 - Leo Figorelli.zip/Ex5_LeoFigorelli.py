while True:
    valor_str = input('Digite um numero de 0 à 9: ')
    try:
        valor_int = int(valor_str)
        validation = valor_int >= 0 and valor_int <= 9
        if validation:
            print('Valor correto!')
        else:
            print('Valor incorreto!')
        break
    except:
        print('Você não digitou um número.')
        continue